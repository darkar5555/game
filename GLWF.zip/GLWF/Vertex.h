//
//  Vertex.h
//  GLWF
//
//  Created by Rodrigo Castro Ramos on 1/21/19.
//  Copyright © 2019 Rodrigo Castro Ramos. All rights reserved.
//


#include<glm/glm.hpp>

struct Vertex
{
    glm::vec3 position;
    glm::vec3 color;
    glm::vec2 texcoord;
    glm::vec3 normal;
};
